EasyKivy provides an easy-to-use interface for simple GUI interaction
with a user based on EasyGUI.

Note that EasyKivy requires Kivy release 1.8.0 or greater.
